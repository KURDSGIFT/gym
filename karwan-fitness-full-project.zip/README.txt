
1- Install Node.js
2- Open backend folder
3- Run: npm install
4- Put your API key inside .env
5- Run: node server.js
6- Open frontend/index.html
